({
   	doInit: function(component, event, helper) {
        helper.getProductsInfoHelper(component, event, helper);
    },
})